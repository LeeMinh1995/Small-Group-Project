'use strict';

angular
	.module('gameApp')
		.config(['$locationProvider','$stateProvider','$urlRouterProvider', function($locationProvider, $stateProvider, $urlRouterProvider) {
			$locationProvider.hashPrefix('');

			$stateProvider
				.state('home', {
					url: '/home',
					controller: function($scope) {
						$scope.pageClass = 'page-home';
					},
					templateUrl: './html/home.html'
				})
				.state('play', {
					url: '/play',
					controller: function($scope) {
						$scope.pageClass = 'page-play';
					},
					templateUrl: './html/play.html'
				})
				.state('tutorial', {
					url: '/tutorial',
					controller: function($scope) {
						$scope.pageClass = 'page-tutorial';
					},
					templateUrl: './html/tutorial.html'
				});

			$urlRouterProvider.otherwise('/home');
		}]);