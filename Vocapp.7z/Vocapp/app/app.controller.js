'use strict';

angular
	.module('gameApp')
		.controller('playController', ['$scope', '$http', function($scope, $http) {

			var word = '';
			var typedWords = [];
			var lastLetter = '';
			var currentScore = 0;
			var lastPosition = 0, newPosition = 0;		

			$scope.timeOut = function(time) {
				$scope.countdown = time;
				var myInterval = setInterval(function() { 
					$scope.countdown = $scope.countdown - 1;
					if ($scope.countdown < 0) {
						clearInterval(myInterval);
						$scope.countdown = 0;
						alert('Your total score is : ' + currentScore);
					}
					$scope.$apply();
				}, 1000);
			}

			$scope.showAlert = function(alertMessage) {
				$('.alert').css('opacity', 1);
				$('.alert').css('visibility', 'visible');
				$scope.alertMessage = alertMessage; 
			}

			$scope.hideAlert = function() {
				$('.alert').css('opacity', 0);
				$('.alert').css('visibility', 'hidden');
			}

			$scope.deletePressed = function($event) {
				var keyCode = $event.which || $event.keyCode;
				if (keyCode == 32) {
					$event.preventDefault();
				}
				if (keyCode == 8 || keyCode == 46) {
					if (lastPosition == $scope.playerText.length - 1) {
						$event.preventDefault();	
						$scope.showAlert('You are not allowed to delete.');	
					}
				}
			};

		    $scope.enterPressed = function($event) {
				var keyCode = $event.which || $event.keyCode;
				if (keyCode == 13) {
					$event.preventDefault();
					if (lastPosition == $scope.playerText.length) {
						$scope.showAlert('You have not typed any word yet.');					
					} else {
						word = $scope.playerText.substr(lastPosition, $scope.playerText.length - lastPosition);
						if (typedWords.includes(word)) {
							$scope.showAlert('You have typed that word already, please choose another word.');
						} else if ($scope.dictionary.data.includes(word)) {
							/* Get last letter of previous word */
							$scope.playerText += ' → ' + $scope.playerText.substr($scope.playerText.length - 1, 1);
							/* Update score */				
							$scope.playerScore = (currentScore+=1).toString();
							/* Update new position */
							lastPosition = $scope.playerText.length - 1;							
							/* Add typed word to an array */
							typedWords.push(word);
							/* Hide alert if it opened*/
							$scope.hideAlert();
						} else {
							$scope.showAlert('Your word is not correct, please check your spell.');					
						}
					}	
				}
			};		

			$scope.loadDictionary = function() {
				$http.get('./EnglishDictionary.json').then(function(data) { 
				   	$scope.dictionary = data;
				});
			}

			$scope.init = function() {
				$scope.loadDictionary();
				$scope.timeOut(60);	
			}

			$scope.init();

		}]);